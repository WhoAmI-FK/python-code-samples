import os
from os import path
import shutil
from shutil import make_archive

def main():
    if path.exists("newfile.txt"):
        src = path.realpath("newfile.txt");
        dst = src + ".bak";
        shutil.copy(src, dst);
        #os.rename("textfile.txt", "newfile.txt")
        root_dir, tail = path.split(src);
        shutil.make_archive("archive", "zip", root_dir);
if __name__ == "__main__":
    main()